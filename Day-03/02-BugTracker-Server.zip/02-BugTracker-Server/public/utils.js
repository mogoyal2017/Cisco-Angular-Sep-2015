angular
    .module('utils', [])
    .value("defaultTrimLength", 20)
    .value('momentApi', moment);
